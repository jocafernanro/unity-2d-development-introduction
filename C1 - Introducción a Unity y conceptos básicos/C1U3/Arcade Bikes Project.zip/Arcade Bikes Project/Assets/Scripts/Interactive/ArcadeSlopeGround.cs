﻿using UnityEngine;
using System.Collections;


public class ArcadeSlopeGround : ArcadeObstacle
{
	//protected override void OnTriggerEnter2D(Collider2D col)
	//{
	//	if (col.CompareTag("ArcadePlayer") && Status == ArcadeObstacleStatus.Default) {
	//		col.SendMessage("Boost");
	//	}
	//}
}